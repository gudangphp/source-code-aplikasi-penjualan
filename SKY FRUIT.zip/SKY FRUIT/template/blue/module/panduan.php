
  <div class="bread"><b style="font-weight:bold">- Panduan Berbelanja</b></div>
<br>
<?php echo $panduan_web ?>